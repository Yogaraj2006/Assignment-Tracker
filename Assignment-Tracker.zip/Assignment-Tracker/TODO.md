# Assignment-Tracker TODO

- [x] Create React components folder and implement:
  - [x] Dashboard.jsx (state, counts, filter)
  - [x] AssignmentForm.jsx (add assignment)
  - [x] AssignmentList.jsx (render cards)
  - [x] AssignmentCard.jsx (status UI)
  - [x] Filter.jsx (subject dropdown)
- [x] Replace template content in src/App.jsx to render Dashboard
- [x] Add/adjust styling in src/App.css

- [x] Ensure app meets features:
  - [x] Add assignment (title, subject, due date)
  - [x] Mark status (Submitted / Pending / Late)
  - [x] Filter by subject
  - [x] Dashboard summary counts
- [x] Run dev server and do quick manual test

- [x] Add delete option for each assignment

- [x] Add file upload when adding an assignment





