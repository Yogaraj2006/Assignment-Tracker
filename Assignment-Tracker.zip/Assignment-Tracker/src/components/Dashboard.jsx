import { useMemo, useState } from 'react';
import AssignmentForm from './AssignmentForm';
import AssignmentList from './AssignmentList';
import Filter from './Filter';

const uid = () => (globalThis.crypto?.randomUUID ? globalThis.crypto.randomUUID() : String(Date.now()));

function normalizeDateInput(value) {
  // value is expected from <input type="date"> i.e. YYYY-MM-DD
  // Normalize to end-of-day local time for reasonable lateness.
  if (!value) return null;
  const [y, m, d] = value.split('-').map((n) => Number(n));
  if (!y || !m || !d) return null;
  const dt = new Date(y, m - 1, d, 23, 59, 59, 999);
  return Number.isNaN(dt.getTime()) ? null : dt;
}

function computeAutoLate(dueDateValue) {
  const due = normalizeDateInput(dueDateValue);
  if (!due) return false;
  return Date.now() > due.getTime();
}

export default function Dashboard() {
  const [assignments, setAssignments] = useState(() => {
    // starter data for better UX
    const now = new Date();
    const toDateInput = (dt) => {
      const y = dt.getFullYear();
      const m = String(dt.getMonth() + 1).padStart(2, '0');
      const d = String(dt.getDate()).padStart(2, '0');
      return `${y}-${m}-${d}`;
    };

    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    return [
      {
        id: uid(),
        title: 'Calculus Worksheet 1',
        subject: 'Mathematics',
        dueDate: toDateInput(yesterday),
        status: 'Pending',
        autoLate: true,
      },
      {
        id: uid(),
        title: 'History Essay Outline',
        subject: 'History',
        dueDate: toDateInput(tomorrow),
        status: 'Submitted',
        autoLate: false,
      },
    ];
  });

  const [subjectFilter, setSubjectFilter] = useState('All');

  const subjects = useMemo(() => {
    const set = new Set(assignments.map((a) => a.subject).filter(Boolean));
    return ['All', ...Array.from(set).sort((a, b) => a.localeCompare(b))];
  }, [assignments]);

  const effectiveAssignments = useMemo(() => {
    // If a record has status not Submitted, we treat Late as either:
    // - user-selected Late
    // - or auto late from due date at render-time
    // This preserves user control while still satisfying auto set.
    return assignments.map((a) => {
      if (a.status === 'Submitted') return a;
      const autoLate = computeAutoLate(a.dueDate);
      const isLate = a.status === 'Late' || autoLate;
      return { ...a, autoLate, status: isLate ? 'Late' : 'Pending' };
    });
  }, [assignments]);

  const filtered = useMemo(() => {
    if (subjectFilter === 'All') return effectiveAssignments;
    return effectiveAssignments.filter((a) => a.subject === subjectFilter);
  }, [effectiveAssignments, subjectFilter]);

  const counts = useMemo(() => {
    let submitted = 0;
    let pending = 0;
    let late = 0;
    for (const a of filtered) {
      if (a.status === 'Submitted') submitted++;
      else if (a.status === 'Late') late++;
      else pending++;
    }
    return { submitted, pending, late, total: filtered.length };
  }, [filtered]);

  const handleAdd = (payload) => {
    const autoLate = computeAutoLate(payload.dueDate);
    setAssignments((prev) => [
      ...prev,
      {
        id: uid(),
        title: payload.title,
        subject: payload.subject,
        dueDate: payload.dueDate,
        status: autoLate ? 'Late' : 'Pending',
        autoLate,
        fileName: payload.fileName ?? null,
        fileDataUrl: payload.fileDataUrl ?? null,
      },
    ]);
  };


  const handleStatusChange = (id, nextStatus) => {
    setAssignments((prev) =>
      prev.map((a) => {
        if (a.id !== id) return a;
        return { ...a, status: nextStatus };
      }),
    );
  };

  const handleDelete = (id) => {
    setAssignments((prev) => prev.filter((a) => a.id !== id));
  };


  return (
    <div className="at-dashboard">
      <header className="at-header">
        <div>
          <h1 className="at-title">College Assignment Submission Tracker</h1>
          <p className="at-subtitle">Track Submitted / Pending / Late assignments across subjects.</p>
        </div>

        <div className="at-summary" aria-label="Dashboard summary">
          <div className="at-pill">
            <div className="at-pill-label">Submitted</div>
            <div className="at-pill-value">{counts.submitted}</div>
          </div>
          <div className="at-pill">
            <div className="at-pill-label">Pending</div>
            <div className="at-pill-value">{counts.pending}</div>
          </div>
          <div className="at-pill at-pill--late">
            <div className="at-pill-label">Late</div>
            <div className="at-pill-value">{counts.late}</div>
          </div>
        </div>
      </header>

      <div className="at-controls">
        <Filter subjects={subjects} value={subjectFilter} onChange={setSubjectFilter} />
        <AssignmentForm onAdd={handleAdd} />
      </div>

      <AssignmentList
        assignments={filtered}
        onStatusChange={handleStatusChange}
        onDelete={handleDelete}
      />

    </div>
  );
}

