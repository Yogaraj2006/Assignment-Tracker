function formatDate(value) {
  if (!value) return '';
  // value is YYYY-MM-DD
  const [y, m, d] = value.split('-').map((n) => Number(n));
  if (!y || !m || !d) return value;
  const dt = new Date(y, m - 1, d);
  return dt.toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' });
}

const statusClass = {
  Submitted: 'at-status--submitted',
  Pending: 'at-status--pending',
  Late: 'at-status--late',
};

export default function AssignmentCard({ assignment, onStatusChange, onDelete }) {
  const { id, title, subject, dueDate, status } = assignment;

  const handleStatus = (next) => onStatusChange(id, next);

  return (
    <article className="at-card" aria-label={`Assignment ${title}`}>
      <div className="at-card-top">
        <div className="at-meta">
          <div className="at-subject">{subject}</div>
          <h3 className="at-card-title">{title}</h3>
          <div className="at-due">Due: {formatDate(dueDate)}</div>
          {assignment.fileName ? (
            <div className="at-file">
              <div className="at-file-label">File: {assignment.fileName}</div>
              {assignment.fileDataUrl ? (
                <a className="at-file-link" href={assignment.fileDataUrl} download={assignment.fileName}>
                  Download
                </a>
              ) : null}
            </div>
          ) : null}
        </div>


        <div className="at-status-block">
          <div className={`at-status ${statusClass[status] ?? ''}`}>{status}</div>

          <div className="at-actions" role="group" aria-label="Set status">
            <button
              type="button"
              className={`at-action-btn ${status === 'Submitted' ? 'is-active' : ''}`}
              onClick={() => handleStatus('Submitted')}
            >
              Submitted
            </button>
            <button
              type="button"
              className={`at-action-btn ${status === 'Pending' ? 'is-active' : ''}`}
              onClick={() => handleStatus('Pending')}
            >
              Pending
            </button>
            <button
              type="button"
              className={`at-action-btn ${status === 'Late' ? 'is-active' : ''}`}
              onClick={() => handleStatus('Late')}
            >
              Late
            </button>
          </div>

          <button
            type="button"
            className="at-delete-btn"
            onClick={() => onDelete?.(id)}
            aria-label={`Delete assignment ${title}`}
          >
            Delete
          </button>
        </div>
      </div>
    </article>
  );
}

