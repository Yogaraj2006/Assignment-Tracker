import AssignmentCard from './AssignmentCard';

export default function AssignmentList({ assignments, onStatusChange, onDelete }) {

  if (!assignments.length) {
    return (
      <section className="at-empty">
        <div className="at-empty-title">No assignments found</div>
        <div className="at-empty-sub">Add an assignment or change the subject filter.</div>
      </section>
    );
  }

  return (
    <section className="at-list" aria-label="Assignments list">
      {assignments.map((a) => (
        <AssignmentCard
          key={a.id}
          assignment={a}
          onStatusChange={onStatusChange}
          onDelete={onDelete}
        />
      ))}

    </section>
  );
}

