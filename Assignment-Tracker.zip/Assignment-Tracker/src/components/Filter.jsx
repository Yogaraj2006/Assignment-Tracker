export default function Filter({ subjects, value, onChange }) {
  return (
    <section className="at-filter" aria-label="Filter by subject">
      <label className="at-filter-label">
        Subject
        <select value={value} onChange={(e) => onChange(e.target.value)}>
          {subjects.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </label>
    </section>
  );
}

