import { useMemo, useState } from 'react';

const initial = { title: '', subject: '', dueDate: '', file: null };


export default function AssignmentForm({ onAdd }) {
  const [form, setForm] = useState(initial);
  const [touched, setTouched] = useState(false);

  const canSubmit = useMemo(() => {
    return form.title.trim().length > 0 &&
      form.subject.trim().length > 0 &&
      String(form.dueDate).trim().length > 0;
  }, [form]);

  const errors = useMemo(() => {
    if (!touched) return {};
    const e = {};
    if (!form.title.trim()) e.title = 'Title is required.';
    if (!form.subject.trim()) e.subject = 'Subject is required.';
    if (!form.dueDate) e.dueDate = 'Due date is required.';
    return e;
  }, [form, touched]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleFile = (e) => {
    const file = e.target.files?.[0] ?? null;
    if (!file) {
      setForm((prev) => ({ ...prev, file: null }));
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const fileDataUrl = String(reader.result ?? '');
      setForm((prev) => ({ ...prev, file: { name: file.name, dataUrl: fileDataUrl } }));
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setTouched(true);
    if (!canSubmit) return;

    onAdd({
      title: form.title.trim(),
      subject: form.subject.trim(),
      dueDate: form.dueDate,
      fileName: form.file?.name ?? null,
      fileDataUrl: form.file?.dataUrl ?? null,
    });

    setForm(initial);
    setTouched(false);
  };


  return (
    <section className="at-form" aria-label="Add assignment">
      <h2 className="at-form-title">Add Assignment</h2>
      <form onSubmit={handleSubmit}>
        <label className="at-field">
          <span className="at-label">Title</span>
          <input
            name="title"
            value={form.title}
            onChange={handleChange}
            placeholder="e.g., Data Structures Lab"
          />
          {errors.title ? <span className="at-error">{errors.title}</span> : null}
        </label>

        <label className="at-field">
          <span className="at-label">Subject</span>
          <input
            name="subject"
            value={form.subject}
            onChange={handleChange}
            placeholder="e.g., Computer Science"
          />
          {errors.subject ? <span className="at-error">{errors.subject}</span> : null}
        </label>

        <label className="at-field">
          <span className="at-label">Due date</span>
          <input
            type="date"
            name="dueDate"
            value={form.dueDate}
            onChange={handleChange}
          />
          {errors.dueDate ? <span className="at-error">{errors.dueDate}</span> : null}
        </label>

        <label className="at-field">
          <span className="at-label">Upload file (optional)</span>
          <input
            type="file"
            onChange={handleFile}
            accept="*/*"
          />
        </label>

        <button className="at-btn" type="submit" disabled={!canSubmit}>

          Add
        </button>
      </form>
    </section>
  );
}

